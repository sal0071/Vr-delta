# Showroom Delta — versão corrigida para WebXR

Esta versão corrige os imports de módulos do Three.js usando um import map. Na versão anterior, o módulo VRButton podia falhar ao resolver o import `three`, mesmo que o botão Enter VR aparecesse.

## Publicação no GitHub Pages
1. Extraia o ZIP.
2. Envie `index.html` e `carrara-cristal-inspirado.png` para a raiz do repositório.
3. Substitua o `index.html` antigo.
4. Em Settings > Pages, selecione `main` e `/(root)`.
5. Espere o GitHub Pages publicar a alteração.
6. No Meta Quest Browser, abra o endereço HTTPS do GitHub Pages, recarregue a página e tente Enter VR.

O Quest precisa de internet para baixar o Three.js do CDN. Feche outras experiências VR antes de tentar iniciar.
